<?php
session_start();
include '../koneksi.php';

// 1. Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Inisialisasi Variabel
$id_edit = ""; $nama_edit = ""; $harga_edit = ""; $stok_edit = ""; $deskripsi_edit = ""; $custom_edit = ""; $gambar_lama = "";
$is_edit = false;

// Lokasi Folder Assets
$target_dir = "../assets/";

// --- LOGIKA CRUD ---

// A. PROSES HAPUS
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $data = mysqli_query($conn, "SELECT gambar FROM produk_buket WHERE id = '$id'");
    $row = mysqli_fetch_assoc($data);
    if ($row['gambar'] != '' && file_exists($target_dir . $row['gambar'])) {
        unlink($target_dir . $row['gambar']);
    }
    mysqli_query($conn, "DELETE FROM produk_buket WHERE id = '$id'");
    header("Location: kelola_produk.php");
}

// B. PROSES AMBIL DATA UNTUK EDIT
if (isset($_GET['edit'])) {
    $id_edit = $_GET['edit'];
    $is_edit = true;
    $result_edit = mysqli_query($conn, "SELECT * FROM produk_buket WHERE id = '$id_edit'");
    $data_edit = mysqli_fetch_assoc($result_edit);
    
    $nama_edit = $data_edit['nama_buket'];
    $harga_edit = $data_edit['harga'];
    $stok_edit = $data_edit['stok'];
    $deskripsi_edit = $data_edit['deskripsi'];
    $custom_edit = $data_edit['custom'];
    $gambar_lama = $data_edit['gambar'];
}

// C. PROSES SIMPAN (TAMBAH / UPDATE)
if (isset($_POST['simpan'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_buket']);
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $custom = $_POST['custom'];
    
    $gambar = $_FILES['gambar']['name'];
    if ($gambar != "") {
        $x = explode('.', $gambar);
        $ekstensi = strtolower(end($x));
        $nama_gambar_baru = time() . "_" . $gambar;
        
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_dir . $nama_gambar_baru)) {
            if ($_POST['id_produk'] != "" && $gambar_lama != "" && file_exists($target_dir . $gambar_lama)) {
                unlink($target_dir . $gambar_lama);
            }
        }
    } else {
        $nama_gambar_baru = ($_POST['id_produk'] != "") ? $_POST['gambar_lama'] : "";
    }

    if ($_POST['id_produk'] == "") {
        $sql = "INSERT INTO produk_buket (nama_buket, harga, stok, deskripsi, gambar, custom) VALUES ('$nama', '$harga', '$stok', '$deskripsi', '$nama_gambar_baru', '$custom')";
    } else {
        $id_upd = $_POST['id_produk'];
        $sql = "UPDATE produk_buket SET nama_buket='$nama', harga='$harga', stok='$stok', deskripsi='$deskripsi', gambar='$nama_gambar_baru', custom='$custom' WHERE id='$id_upd'";
    }

    if (mysqli_query($conn, $sql)) {
        header("Location: kelola_produk.php");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Produk | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3498db;
            --dark-blue: #2980b9;
            --bg-body: #f4f7f6;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--bg-body); min-height: 100vh; overflow-x: hidden; }

        /* --- ANIMATIONS --- */
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Navbar Atas */
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 15px 5%;
            display: flex; justify-content: space-between; align-items: center;
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
            animation: slideDown 0.6s ease;
        }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 20px; }
        .nav-links { display: flex; gap: 15px; }
        .nav-links a { 
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 14px; 
            transition: 0.3s; padding: 8px 12px; border-radius: 8px;
        }
        .nav-links a:hover, .nav-links a.active { color: white; background: rgba(255,255,255,0.2); }

        .container { padding: 40px 5%; }

        .card { 
            background: var(--white); padding: 30px; border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 30px; 
            animation: fadeInUp 0.7s ease forwards;
        }
        
        h2 { color: #333; margin-bottom: 25px; font-size: 20px; border-left: 5px solid var(--primary-blue); padding-left: 15px; }
        
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #555; }
        .input-group input, .input-group select, .input-group textarea { 
            width: 100%; padding: 12px 15px; border: 1.5px solid #eee; 
            border-radius: 12px; outline: none; transition: 0.3s; 
        }
        .input-group input:focus { border-color: var(--primary-blue); box-shadow: 0 0 8px rgba(52, 152, 219, 0.1); }
        
        .btn-simpan { 
            background: var(--primary-blue); color: white; border: none; 
            padding: 12px 25px; border-radius: 12px; font-weight: 600; 
            cursor: pointer; transition: 0.3s; 
        }
        .btn-simpan:hover { background: var(--dark-blue); transform: scale(1.03); }
        .btn-batal { background: #eee; color: #666; text-decoration: none; padding: 12px 25px; border-radius: 12px; font-size: 14px; margin-left: 10px; }

        /* Table */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table th { text-align: left; padding: 15px; background: #f4f8ff; color: var(--dark-blue); font-size: 14px; }
        table td { padding: 15px; border-bottom: 1px solid #f0f0f0; font-size: 14px; vertical-align: middle; transition: 0.3s; }
        tr:hover td { background-color: #fafcff; }
        .img-td { width: 65px; height: 65px; object-fit: cover; border-radius: 12px; border: 2px solid #eee; }
        .action-icons a { margin-right: 15px; font-size: 18px; transition: 0.2s; }
        .action-icons a:hover { transform: scale(1.2); display: inline-block; }

        .btn-logout { background: #ff4d4d; color: white !important; border-radius: 8px; font-weight: 600; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <i class="fas fa-shopping-basket"></i>
            <span>Buketin Aja</span>
        </div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="kelola_produk.php" class="active">Produk</a>
            <a href="kelola_pembayaran.php">Pembayaran</a>
            <a href="kelola_pengiriman.php">Pengiriman</a>
            <a href="riwayat_pesanan.php">Riwayat</a>
            <a href="data_pelanggan.php">Pelanggan</a>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h2><?php echo $is_edit ? 'Edit Produk' : 'Tambah Produk Baru'; ?></h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id_produk" value="<?php echo $id_edit; ?>">
                <input type="hidden" name="gambar_lama" value="<?php echo $gambar_lama; ?>">
                
                <div class="form-grid">
                    <div class="input-group">
                        <label>Nama Buket</label>
                        <input type="text" name="nama_buket" value="<?php echo $nama_edit; ?>" required>
                    </div>
                    <div class="input-group">
                        <label>Harga (Rp)</label>
                        <input type="number" name="harga" value="<?php echo $harga_edit; ?>" required>
                    </div>
                    <div class="input-group">
                        <label>Stok</label>
                        <input type="number" name="stok" value="<?php echo $stok_edit; ?>" required>
                    </div>
                    <div class="input-group">
                        <label>Bisa Custom?</label>
                        <select name="custom">
                            <option value="tidak" <?php if($custom_edit == 'tidak') echo 'selected'; ?>>Tidak</option>
                            <option value="ya" <?php if($custom_edit == 'ya') echo 'selected'; ?>>Ya</option>
                        </select>
                    </div>
                </div>
                <div class="input-group">
                    <label>Deskripsi</label>
                    <textarea name="deskripsi" rows="3"><?php echo $deskripsi_edit; ?></textarea>
                </div>
                <div class="input-group">
                    <label>Gambar Produk</label>
                    <input type="file" name="gambar" <?php echo $is_edit ? '' : 'required'; ?>>
                </div>

                <button type="submit" name="simpan" class="btn-simpan">
                    <i class="fas fa-save"></i> <?php echo $is_edit ? 'Update Produk' : 'Simpan Produk'; ?>
                </button>
                <?php if($is_edit) : ?>
                    <a href="kelola_produk.php" class="btn-batal">Batal</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="card" style="animation-delay: 0.2s;">
            <h2>Daftar Produk di Assets</h2>
            <table>
                <thead>
                    <tr>
                        <th>Gambar</th>
                        <th>Nama</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $res = mysqli_query($conn, "SELECT * FROM produk_buket ORDER BY id DESC");
                    while($row = mysqli_fetch_assoc($res)) :
                    ?>
                    <tr>
                        <td>
                            <?php if($row['gambar'] != ""): ?>
                                <img src="../assets/<?php echo $row['gambar']; ?>" class="img-td">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/65" class="img-td">
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo $row['nama_buket']; ?></strong></td>
                        <td>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td><?php echo $row['stok']; ?></td>
                        <td class="action-icons">
                            <a href="kelola_produk.php?edit=<?php echo $row['id']; ?>" style="color: #f1c40f;"><i class="fas fa-edit"></i></a>
                            <a href="kelola_produk.php?hapus=<?php echo $row['id']; ?>" style="color: #e74c3c;" onclick="return confirm('Hapus produk?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>