<?php
session_start();
include '../koneksi.php';

// 1. Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Inisialisasi Variabel
$id_edit = ""; $pesanan_id = ""; $kurir = ""; $layanan = ""; $ongkir = ""; $no_resi = ""; $status_kirim = ""; $alamat = "";
$is_edit = false;

// --- LOGIKA CRUD PENGIRIMAN ---

// A. PROSES HAPUS
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pengiriman WHERE id = '$id'");
    header("Location: kelola_pengiriman.php");
}

// B. PROSES AMBIL DATA UNTUK EDIT
if (isset($_GET['edit'])) {
    $id_edit = $_GET['edit'];
    $is_edit = true;
    $result_edit = mysqli_query($conn, "SELECT * FROM pengiriman WHERE id = '$id_edit'");
    $data_edit = mysqli_fetch_assoc($result_edit);
    
    $pesanan_id = $data_edit['pesanan_id'];
    $kurir = $data_edit['kurir'];
    $layanan = $data_edit['layanan'];
    $ongkir = $data_edit['ongkir'];
    $no_resi = $data_edit['no_resi'];
    $status_kirim = $data_edit['status'];
    $alamat = $data_edit['alamat_kirim'];
}

// C. PROSES SIMPAN (TAMBAH / UPDATE)
if (isset($_POST['simpan'])) {
    $p_id = $_POST['pesanan_id'];
    $kur = mysqli_real_escape_string($conn, $_POST['kurir']);
    $resi = mysqli_real_escape_string($conn, $_POST['no_resi']);
    $stat = $_POST['status'];
    $alm = mysqli_real_escape_string($conn, $_POST['alamat_kirim']);

    if ($_POST['id_pengiriman'] == "") {
        $sql = "INSERT INTO pengiriman (pesanan_id, kurir, no_resi, status, alamat_kirim) 
                VALUES ('$p_id', '$kur', '$resi', '$stat', '$alm')";
    } else {
        $id_upd = $_POST['id_pengiriman'];
        $sql = "UPDATE pengiriman SET 
                pesanan_id='$p_id', kurir='$kur', 
                no_resi='$resi', status='$stat', alamat_kirim='$alm' 
                WHERE id='$id_upd'";
    }

    if (mysqli_query($conn, $sql)) {
        header("Location: kelola_pengiriman.php");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengiriman | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3498db;
            --dark-blue: #2980b9;
            --bg-body: #f4f7f6;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--bg-body); min-height: 100vh; overflow-x: hidden; }

        /* --- ANIMATIONS --- */
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Navbar Atas */
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 15px 5%;
            display: flex; justify-content: space-between; align-items: center;
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
            animation: slideDown 0.6s ease;
        }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 20px; }
        .nav-links { display: flex; gap: 15px; }
        .nav-links a { 
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 14px; 
            transition: 0.3s; padding: 8px 12px; border-radius: 8px;
        }
        .nav-links a:hover, .nav-links a.active { color: white; background: rgba(255,255,255,0.2); }

        .container { padding: 40px 5%; }

        /* Card Style */
        .card { 
            background: var(--white); padding: 30px; border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 30px;
            animation: fadeInUp 0.7s ease forwards;
        }
        
        h2 { color: #333; margin-bottom: 25px; font-size: 20px; border-left: 5px solid var(--primary-blue); padding-left: 15px; }
        
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #555; }
        .input-group input, .input-group select, .input-group textarea { 
            width: 100%; padding: 12px 15px; border: 1.5px solid #eee; 
            border-radius: 12px; outline: none; transition: 0.3s; 
        }
        .input-group input:focus { border-color: var(--primary-blue); }
        
        .btn-simpan { 
            background: var(--primary-blue); color: white; border: none; 
            padding: 12px 25px; border-radius: 12px; font-weight: 600; 
            cursor: pointer; transition: 0.3s; 
        }
        .btn-simpan:hover { background: var(--dark-blue); transform: scale(1.03); }

        /* Table Style */
        table { width: 100%; border-collapse: collapse; }
        table th { text-align: left; padding: 15px; background: #f4f8ff; color: var(--dark-blue); font-size: 14px; }
        table td { padding: 15px; border-bottom: 1px solid #f0f0f0; font-size: 14px; vertical-align: middle; transition: 0.3s; }
        tr:hover td { background-color: #fafcff; }
        
        .status-badge { padding: 6px 14px; border-radius: 30px; font-size: 12px; font-weight: 600; }
        .status-menunggu { background: #fff4de; color: #ffa800; }
        .status-dikirim { background: #e1f0ff; color: #3699ff; }
        .status-diterima { background: #c9f7f5; color: #1bc5bd; }

        .btn-logout { background: #ff4d4d; color: white !important; border-radius: 8px; font-weight: 600; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <i class="fas fa-shopping-basket"></i>
            <span>Buketin Aja</span>
        </div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="kelola_produk.php">Produk</a>
            <a href="kelola_pembayaran.php">Pembayaran</a>
            <a href="kelola_pengiriman.php" class="active">Pengiriman</a>
            <a href="riwayat_pesanan.php">Riwayat</a>
            <a href="data_pelanggan.php">Pelanggan</a>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h2><?php echo $is_edit ? 'Update Resi & Status' : 'Input Data Pengiriman'; ?></h2>
            <form method="POST">
                <input type="hidden" name="id_pengiriman" value="<?php echo $id_edit; ?>">
                
                <div class="form-grid">
                    <div class="input-group">
                        <label>Pilih Pesanan (ID - Nama)</label>
                        <select name="pesanan_id" required>
                            <?php 
                            $orders = mysqli_query($conn, "SELECT id_pesanan, nama_pembeli FROM orders");
                            while($o = mysqli_fetch_assoc($orders)) {
                                $sel = ($o['id_pesanan'] == $pesanan_id) ? "selected" : "";
                                echo "<option value='".$o['id_pesanan']."' $sel>#".$o['id_pesanan']." - ".$o['nama_pembeli']."</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="input-group">
                        <label>Kurir (JNE/Pos/Dsb)</label>
                        <input type="text" name="kurir" value="<?php echo $kurir; ?>" required>
                    </div>
                    <div class="input-group">
                        <label>No Resi</label>
                        <input type="text" name="no_resi" value="<?php echo $no_resi; ?>" placeholder="Masukkan resi">
                    </div>
                    <div class="input-group">
                        <label>Status Pengiriman</label>
                        <select name="status">
                            <option value="menunggu" <?php if($status_kirim == 'menunggu') echo 'selected'; ?>>Menunggu</option>
                            <option value="dikirim" <?php if($status_kirim == 'dikirim') echo 'selected'; ?>>Dikirim</option>
                            <option value="diterima" <?php if($status_kirim == 'diterima') echo 'selected'; ?>>Diterima</option>
                        </select>
                    </div>
                </div>
                <div class="input-group">
                    <label>Alamat Lengkap Tujuan</label>
                    <textarea name="alamat_kirim" rows="2" required><?php echo $alamat; ?></textarea>
                </div>

                <button type="submit" name="simpan" class="btn-simpan">
                    <i class="fas fa-shipping-fast"></i> Simpan Data Pengiriman
                </button>
                <?php if($is_edit) : ?>
                    <a href="kelola_pengiriman.php" style="margin-left:15px; color:#666; text-decoration:none; font-size:14px;">Batal</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="card" style="animation-delay: 0.2s;">
            <h2>Monitoring Pengiriman</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID Pesan</th>
                        <th>Penerima</th>
                        <th>Kurir</th>
                        <th>No Resi</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $res = mysqli_query($conn, "SELECT p.*, o.nama_pembeli FROM pengiriman p JOIN orders o ON p.pesanan_id = o.id_pesanan ORDER BY p.id DESC");
                    while($row = mysqli_fetch_assoc($res)) :
                    ?>
                    <tr>
                        <td style="font-weight: 600; color: var(--primary-blue);">#BK-<?php echo $row['pesanan_id']; ?></td>
                        <td><strong><?php echo $row['nama_pembeli']; ?></strong></td>
                        <td><?php echo $row['kurir']; ?></td>
                        <td><code><?php echo $row['no_resi'] ? $row['no_resi'] : '-'; ?></code></td>
                        <td>
                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                <i class="fas fa-circle" style="font-size: 8px; margin-right: 5px;"></i>
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="kelola_pengiriman.php?edit=<?php echo $row['id']; ?>" style="color: #f1c40f; margin-right:15px;"><i class="fas fa-edit"></i></a>
                            <a href="kelola_pengiriman.php?hapus=<?php echo $row['id']; ?>" style="color: #e74c3c;" onclick="return confirm('Hapus data?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>