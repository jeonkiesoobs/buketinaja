<?php
session_start();
include '../koneksi.php'; 

// Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Statistik Real-time
$total_produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM produk_buket"))['total'];
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users_new WHERE role='user'"))['total'];
$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM orders"))['total'];
$total_delivery_pending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM pengiriman WHERE status='menunggu'"))['total'];
$total_pembayaran_pending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM pembayaran WHERE status='pending'"))['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3498db;
            --dark-blue: #2980b9;
            --bg-body: #f4f7f6;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--bg-body); min-height: 100vh; overflow-x: hidden; }

        /* --- ANIMATIONS --- */
        @keyframes slideDown { from { opacity: 0; transform: translateY(-50px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        /* Navbar Atas */
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 15px 5%;
            display: flex; justify-content: space-between; align-items: center;
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
            animation: slideDown 0.6s ease;
        }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 20px; }
        .nav-links { display: flex; gap: 15px; }
        .nav-links a { 
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 14px; 
            transition: 0.3s; padding: 8px 12px; border-radius: 8px;
        }
        .nav-links a:hover, .nav-links a.active { color: white; background: rgba(255,255,255,0.2); }

        .container { padding: 40px 5%; }
        .welcome-msg { margin-bottom: 30px; animation: fadeIn 1s ease; }

        /* Stats Cards */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px; }
        .stat-card {
            background: var(--white); padding: 25px; border-radius: 15px;
            display: flex; align-items: center; gap: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.05);
            transition: 0.4s; opacity: 0; animation: fadeInUp 0.6s forwards;
        }
        .stat-card:hover { transform: translateY(-8px); box-shadow: 0 12px 25px rgba(52, 152, 219, 0.2); }
        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }
        .stat-card:nth-child(4) { animation-delay: 0.4s; }
        .stat-card:nth-child(5) { animation-delay: 0.5s; }

        .stat-icon {
            width: 55px; height: 55px; background: #ebf5ff;
            color: var(--primary-blue); border-radius: 12px;
            display: flex; align-items: center; justify-content: center; font-size: 22px;
        }
        .stat-info h3 { font-size: 24px; color: #333; }
        .stat-info p { font-size: 12px; color: #888; }

        /* Table Card */
        .table-card {
            background: var(--white); padding: 30px; border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            opacity: 0; animation: fadeIn 0.8s forwards; animation-delay: 0.7s;
        }
        table { width: 100%; border-collapse: collapse; }
        table th { text-align: left; padding: 15px; background: #fafafa; font-size: 14px; color: #777; }
        table td { padding: 15px; border-bottom: 1px solid #f1f1f1; font-size: 14px; }

        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .status-pending { background: #fff4de; color: #ffa800; }
        .status-proses { background: #e1f0ff; color: #3699ff; }
        .status-selesai { background: #c9f7f5; color: #1bc5bd; }

        .btn-logout { background: #ff4d4d !important; color: white !important; border-radius: 8px; font-weight: 600; }
        .btn-logout:hover { background: #cc0000 !important; transform: scale(1.05); }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo"><i class="fas fa-shopping-basket"></i> <span>Buketin Aja</span></div>
        <div class="nav-links">
            <a href="admin_dashboard.php" class="active">Dashboard</a>
            <a href="kelola_produk.php">Produk</a>
            <a href="kelola_pembayaran.php">Pembayaran</a>
            <a href="kelola_pengiriman.php">Pengiriman</a>
            <a href="riwayat_pesanan.php">Riwayat</a>
            <a href="data_pelanggan.php">Pelanggan</a>
            <a href="logout.php" class="btn-logout" onclick="return confirm('Yakin ingin keluar?')">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="welcome-msg">
            <h2>Halo, <?php echo $_SESSION['nama']; ?>!</h2>
            <p style="color: #888;">Ringkasan bisnis Buketin Aja hari ini.</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-box"></i></div>
                <div class="stat-info"><h3><?php echo $total_produk; ?></h3><p>Total Produk</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                <div class="stat-info"><h3><?php echo $total_orders; ?></h3><p>Total Pesanan</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-info"><h3><?php echo $total_users; ?></h3><p>Pelanggan</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-wallet"></i></div>
                <div class="stat-info"><h3><?php echo $total_pembayaran_pending; ?></h3><p>Bayar Pending</p></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-truck"></i></div>
                <div class="stat-info"><h3><?php echo $total_delivery_pending; ?></h3><p>Kirim Pending</p></div>
            </div>
        </div>

        <div class="table-card">
            <h2 style="margin-bottom: 20px; font-size: 18px;">Pesanan Terbaru</h2>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Pelanggan</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $orders_query = mysqli_query($conn, "SELECT * FROM orders ORDER BY tgl_pesan DESC LIMIT 5");
                    while($order = mysqli_fetch_assoc($orders_query)) :
                    ?>
                    <tr>
                        <td style="font-weight: 600;">#BK-<?php echo $order['id_pesanan']; ?></td>
                        <td><?php echo $order['nama_pembeli']; ?></td>
                        <td><?php echo date('d M Y', strtotime($order['tgl_pesan'])); ?></td>
                        <td><strong>Rp <?php echo number_format($order['total_harga'], 0, ',', '.'); ?></strong></td>
                        <td><span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>