<?php
session_start();
include '../koneksi.php';

// 1. Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Logika Pencarian & Filter
$where = "";
if (isset($_POST['cari'])) {
    $keyword = mysqli_real_escape_string($conn, $_POST['keyword']);
    $status_filter = $_POST['status_filter'];
    
    $conditions = [];
    if (!empty($keyword)) {
        $conditions[] = "(nama_pembeli LIKE '%$keyword%' OR id_pesanan LIKE '%$keyword%')";
    }
    if (!empty($status_filter)) {
        $conditions[] = "status = '$status_filter'";
    }
    
    if (count($conditions) > 0) {
        $where = " WHERE " . implode(" AND ", $conditions);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3498db;
            --dark-blue: #2980b9;
            --bg-body: #f4f7f6;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--bg-body); min-height: 100vh; overflow-x: hidden; }

        /* --- ANIMATIONS --- */
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Navbar Atas */
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 15px 5%;
            display: flex; justify-content: space-between; align-items: center;
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
            animation: slideDown 0.6s ease;
        }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 20px; }
        .nav-links { display: flex; gap: 15px; }
        .nav-links a { 
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 14px; 
            transition: 0.3s; padding: 8px 12px; border-radius: 8px;
        }
        .nav-links a:hover, .nav-links a.active { color: white; background: rgba(255,255,255,0.2); }

        .container { padding: 40px 5%; }

        /* Card Style */
        .card { 
            background: var(--white); padding: 30px; border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 25px;
            animation: fadeInUp 0.7s ease forwards;
        }
        
        h2 { color: #333; margin-bottom: 20px; font-size: 20px; border-left: 5px solid var(--primary-blue); padding-left: 15px; }

        /* Filter Box */
        .filter-box { display: flex; gap: 20px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 8px; flex: 1; min-width: 200px; }
        .filter-group label { font-size: 13px; font-weight: 600; color: #555; }
        .filter-group input, .filter-group select { 
            padding: 12px; border: 1.5px solid #eee; border-radius: 12px; outline: none; transition: 0.3s;
        }
        .filter-group input:focus, .filter-group select:focus { border-color: var(--primary-blue); }
        
        .btn-filter { 
            background: var(--primary-blue); color: white; border: none; 
            padding: 12px 25px; border-radius: 12px; cursor: pointer; 
            font-weight: 600; transition: 0.3s;
        }
        .btn-filter:hover { background: var(--dark-blue); transform: scale(1.03); }

        /* Table Style */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table th { text-align: left; padding: 15px; background: #f4f8ff; color: var(--dark-blue); font-size: 14px; }
        table td { padding: 15px; border-bottom: 1px solid #f0f0f0; font-size: 14px; transition: 0.3s; }
        tr:hover td { background-color: #fafcff; }
        
        .status-badge { padding: 6px 14px; border-radius: 30px; font-size: 11px; font-weight: 600; display: inline-block; }
        .status-pending { background: #fff4de; color: #ffa800; }
        .status-proses { background: #e1f0ff; color: #3699ff; }
        .status-dikirim { background: #dcfce7; color: #15803d; }
        .status-selesai { background: #c9f7f5; color: #1bc5bd; }

        .btn-detail { 
            color: var(--primary-blue); text-decoration: none; font-weight: 600; 
            font-size: 13px; transition: 0.2s; 
        }
        .btn-detail:hover { color: var(--dark-blue); text-decoration: underline; }

        .btn-logout { background: #ff4d4d; color: white !important; border-radius: 8px; font-weight: 600; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <i class="fas fa-shopping-basket"></i>
            <span>Buketin Aja</span>
        </div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="kelola_produk.php">Produk</a>
            <a href="kelola_pembayaran.php">Pembayaran</a>
            <a href="kelola_pengiriman.php">Pengiriman</a>
            <a href="riwayat_pesanan.php" class="active">Riwayat</a>
            <a href="data_pelanggan.php">Pelanggan</a>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h2>Pencarian Riwayat Pesanan</h2>
            <form method="POST" class="filter-box">
                <div class="filter-group">
                    <label>Nama Pembeli / Order ID</label>
                    <input type="text" name="keyword" placeholder="Contoh: Yeni..." value="<?php echo isset($_POST['keyword']) ? $_POST['keyword'] : ''; ?>">
                </div>
                <div class="filter-group">
                    <label>Status Pesanan</label>
                    <select name="status_filter">
                        <option value="">Semua Status</option>
                        <option value="pending" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="proses" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'proses') ? 'selected' : ''; ?>>Proses</option>
                        <option value="dikirim" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'dikirim') ? 'selected' : ''; ?>>Dikirim</option>
                        <option value="selesai" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'selesai') ? 'selected' : ''; ?>>Selesai</option>
                    </select>
                </div>
                <button type="submit" name="cari" class="btn-filter">
                    <i class="fas fa-search"></i> Filter Data
                </button>
                <a href="riwayat_pesanan.php" style="font-size: 13px; color: #888; text-decoration: none; padding-bottom: 12px;">Reset</a>
            </form>
        </div>

        <div class="card" style="animation-delay: 0.2s;">
            <h2>Daftar Riwayat Transaksi</h2>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Nama Pembeli</th>
                        <th>Tanggal Pesan</th>
                        <th>Total Harga</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM orders $where ORDER BY tgl_pesan DESC";
                    $res = mysqli_query($conn, $query);
                    if (mysqli_num_rows($res) > 0) {
                        while($row = mysqli_fetch_assoc($res)) :
                    ?>
                    <tr>
                        <td style="font-weight: 600; color: var(--primary-blue);">#BK-<?php echo $row['id_pesanan']; ?></td>
                        <td><strong><?php echo $row['nama_pembeli']; ?></strong></td>
                        <td><?php echo date('d M Y, H:i', strtotime($row['tgl_pesan'])); ?></td>
                        <td><strong>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></strong></td>
                        <td>
                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                <i class="fas fa-circle" style="font-size: 8px; margin-right: 5px;"></i>
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="detail_pesanan.php?id=<?php echo $row['id_pesanan']; ?>" class="btn-detail">
                                <i class="fas fa-eye"></i> Detail
                            </a>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center; padding: 30px; color: #999;'>Data transaksi tidak ditemukan.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>