<?php
session_start();
include '../koneksi.php'; // Memastikan koneksi ke database buketin_aja

// 1. Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Logika Hapus Pelanggan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    // Menghapus data user berdasarkan ID
    mysqli_query($conn, "DELETE FROM users_new WHERE id = '$id' AND role = 'user'");
    header("Location: data_pelanggan.php?pesan=dihapus");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3498db;
            --dark-blue: #2980b9;
            --bg-body: #f4f7f6;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--bg-body); min-height: 100vh; overflow-x: hidden; }

        /* --- ANIMATIONS --- */
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Navbar Atas */
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 15px 5%;
            display: flex; justify-content: space-between; align-items: center;
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
            animation: slideDown 0.6s ease;
        }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 20px; }
        .nav-links { display: flex; gap: 15px; }
        .nav-links a { 
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 14px; 
            transition: 0.3s; padding: 8px 12px; border-radius: 8px;
        }
        .nav-links a:hover, .nav-links a.active { color: white; background: rgba(255,255,255,0.2); }

        .container { padding: 40px 5%; }

        /* Card Style */
        .card { 
            background: var(--white); padding: 30px; border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            animation: fadeInUp 0.7s ease forwards;
        }
        
        h2 { color: #333; margin-bottom: 25px; font-size: 20px; border-left: 5px solid var(--primary-blue); padding-left: 15px; }

        /* Table Style */
        table { width: 100%; border-collapse: collapse; }
        table th { text-align: left; padding: 15px; background: #f4f8ff; color: var(--dark-blue); font-size: 14px; }
        table td { padding: 15px; border-bottom: 1px solid #f0f0f0; font-size: 14px; vertical-align: middle; transition: 0.3s; }
        tr:hover td { background-color: #fafcff; }
        
        .user-profil { 
            width: 50px; height: 50px; border-radius: 50%; 
            object-fit: cover; border: 2px solid var(--primary-blue);
            transition: 0.3s;
        }
        .user-profil:hover { transform: scale(1.1); }
        
        .badge-user { 
            background: #e1f0ff; color: var(--primary-blue); 
            padding: 6px 14px; border-radius: 30px; 
            font-size: 11px; font-weight: 600; 
            display: inline-block;
        }
        
        .btn-hapus { 
            color: #e74c3c; font-size: 18px; text-decoration: none; 
            transition: 0.3s; display: inline-block;
        }
        .btn-hapus:hover { color: #c0392b; transform: scale(1.2); }

        .btn-logout { background: #ff4d4d; color: white !important; border-radius: 8px; font-weight: 600; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <i class="fas fa-shopping-basket"></i>
            <span>Buketin Aja</span>
        </div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="kelola_produk.php">Produk</a>
            <a href="kelola_pembayaran.php">Pembayaran</a>
            <a href="kelola_pengiriman.php">Pengiriman</a>
            <a href="riwayat_pesanan.php">Riwayat</a>
            <a href="data_pelanggan.php" class="active">Pelanggan</a>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h2>Daftar Pelanggan Terdaftar</h2>
            <table>
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Mengambil data user hanya dengan role 'user' dari tabel users_new
                    $result = mysqli_query($conn, "SELECT * FROM users_new WHERE role = 'user' ORDER BY created_at DESC");
                    if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) :
                    ?>
                    <tr>
                        <td>
                            <img src="../assets/<?php echo $row['foto_profil']; ?>" class="user-profil" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($row['nama_lengkap']); ?>&background=random&color=fff'">
                        </td>
                        <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><span class="badge-user"><i class="fas fa-check-circle" style="font-size: 10px; margin-right: 5px;"></i> Pelanggan Aktif</span></td>
                        <td>
                            <a href="data_pelanggan.php?hapus=<?php echo $row['id']; ?>" class="btn-hapus" title="Hapus Pelanggan" onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan ini? Semua riwayat pesanan mungkin terdampak.')">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center; padding: 30px; color: #999;'>Belum ada pelanggan terdaftar.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>