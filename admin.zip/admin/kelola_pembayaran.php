<?php
session_start();
include '../koneksi.php';

// 1. Proteksi Halaman Admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// 2. Logika Update Status Pembayaran
if (isset($_GET['aksi']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $aksi = $_GET['aksi'];
    
    // Status sesuai ENUM di database: 'pending', 'valid', 'ditolak'
    $status = ($aksi == 'valid') ? 'valid' : 'ditolak';
    
    $query = "UPDATE pembayaran SET status = '$status' WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Status pembayaran berhasil diperbarui!'); window.location='kelola_pembayaran.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pembayaran | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #3498db;
            --dark-blue: #2980b9;
            --bg-body: #f4f7f6;
            --white: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background-color: var(--bg-body); min-height: 100vh; overflow-x: hidden; }

        /* --- ANIMATIONS --- */
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Navbar Atas */
        .navbar {
            background: linear-gradient(135deg, var(--primary-blue), var(--dark-blue));
            padding: 15px 5%;
            display: flex; justify-content: space-between; align-items: center;
            color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
            animation: slideDown 0.6s ease;
        }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 20px; }
        .nav-links { display: flex; gap: 15px; }
        .nav-links a { 
            color: rgba(255,255,255,0.8); text-decoration: none; font-size: 14px; 
            transition: 0.3s; padding: 8px 12px; border-radius: 8px;
        }
        .nav-links a:hover, .nav-links a.active { color: white; background: rgba(255,255,255,0.2); }

        .container { padding: 40px 5%; }

        /* Card Style */
        .card { 
            background: var(--white); padding: 30px; border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
            animation: fadeInUp 0.7s ease forwards;
        }
        
        h2 { color: #333; margin-bottom: 25px; font-size: 20px; border-left: 5px solid var(--primary-blue); padding-left: 15px; }

        /* Table Style */
        table { width: 100%; border-collapse: collapse; }
        table th { text-align: left; padding: 15px; background: #f4f8ff; color: var(--dark-blue); font-size: 14px; }
        table td { padding: 15px; border-bottom: 1px solid #f0f0f0; font-size: 14px; vertical-align: middle; transition: 0.3s; }
        tr:hover td { background-color: #fafcff; }
        
        .bukti-img { 
            width: 100px; height: 100px; object-fit: cover; 
            border-radius: 12px; cursor: pointer; transition: 0.3s; 
            border: 2px solid #eee; 
        }
        .bukti-img:hover { transform: scale(1.1); border-color: var(--primary-blue); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        
        /* Badges */
        .status-badge { padding: 6px 14px; border-radius: 30px; font-size: 12px; font-weight: 600; display: inline-block; }
        .status-pending { background: #fff4de; color: #ffa800; }
        .status-valid { background: #c9f7f5; color: #1bc5bd; }
        .status-ditolak { background: #ffe2e5; color: #f64e60; }

        /* Buttons */
        .btn-action { 
            padding: 8px 16px; border-radius: 10px; text-decoration: none; 
            font-size: 12px; font-weight: 600; transition: 0.3s; 
            display: inline-block; border: none; cursor: pointer;
        }
        .btn-valid { background: #1bc5bd; color: white; margin-right: 5px; }
        .btn-valid:hover { background: #15a39c; transform: translateY(-2px); }
        .btn-tolak { background: #f64e60; color: white; }
        .btn-tolak:hover { background: #e04455; transform: translateY(-2px); }
        
        .btn-logout { background: #ff4d4d; color: white !important; border-radius: 8px; font-weight: 600; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <i class="fas fa-shopping-basket"></i>
            <span>Buketin Aja</span>
        </div>
        <div class="nav-links">
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="kelola_produk.php">Produk</a>
            <a href="kelola_pembayaran.php" class="active">Pembayaran</a>
            <a href="kelola_pengiriman.php">Pengiriman</a>
            <a href="riwayat_pesanan.php">Riwayat</a>
            <a href="data_pelanggan.php">Pelanggan</a>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h2>Konfirmasi Pembayaran Pelanggan</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Metode</th>
                        <th>Bukti Bayar</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Ambil data pembayaran dari database
                    $res = mysqli_query($conn, "SELECT * FROM pembayaran ORDER BY created_at DESC");
                    if (mysqli_num_rows($res) > 0) {
                        while($row = mysqli_fetch_assoc($res)) :
                    ?>
                    <tr>
                        <td style="font-weight: 600; color: var(--primary-blue);">#BK-<?php echo $row['id_pesanan']; ?></td>
                        <td><span style="text-transform: uppercase; font-weight: 500;"><?php echo $row['metode']; ?></span></td>
                        <td>
                            <a href="../assets/<?php echo $row['bukti_pembayaran']; ?>" target="_blank">
                                <img src="../assets/<?php echo $row['bukti_pembayaran']; ?>" class="bukti-img" onerror="this.src='https://via.placeholder.com/100?text=No+Image'">
                            </a>
                        </td>
                        <td>
                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                <i class="fas fa-circle" style="font-size: 8px; margin-right: 5px;"></i>
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if($row['status'] == 'pending') : ?>
                                <a href="kelola_pembayaran.php?aksi=valid&id=<?php echo $row['id']; ?>" class="btn-action btn-valid" onclick="return confirm('Setujui pembayaran ini?')">
                                    <i class="fas fa-check"></i> Valid
                                </a>
                                <a href="kelola_pembayaran.php?aksi=tolak&id=<?php echo $row['id']; ?>" class="btn-action btn-tolak" onclick="return confirm('Tolak pembayaran ini?')">
                                    <i class="fas fa-times"></i> Tolak
                                </a>
                            <?php else : ?>
                                <span style="color: #bbb; font-style: italic; font-size: 12px;">Selesai diproses</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    } else {
                        echo "<tr><td colspan='5' style='text-align:center; padding: 30px; color: #888;'>Belum ada data pembayaran masuk.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>