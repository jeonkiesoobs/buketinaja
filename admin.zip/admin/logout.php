<?php
session_start();

// 1. Hapus semua data session
session_unset();

// 2. Hancurkan session
session_destroy();

// 3. Arahkan ke halaman login di luar folder admin
echo "<script>
    alert('Anda telah berhasil logout.');
    window.location.href = '../login.php';
</script>";
exit;
?>