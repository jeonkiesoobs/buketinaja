<?php
session_start();
include '../koneksi.php';
$id = $_GET['id'] ?? 0;
$action = $_GET['action'] ?? '';
$q = mysqli_query($conn, "SELECT * FROM produk_buket WHERE id = '$id' OR id_produk = '$id' LIMIT 1");
$p = mysqli_fetch_assoc($q);
if ($p) {
    if ($action == 'add' || $action == 'plus') {
        if (isset($_SESSION['cart'][$id])) { $_SESSION['cart'][$id]['qty']++; }
        else { $_SESSION['cart'][$id] = ['nama' => $p['nama_buket'], 'harga' => $p['harga'], 'gambar' => $p['gambar'], 'qty' => 1]; }
    } elseif ($action == 'minus') {
        if ($_SESSION['cart'][$id]['qty'] > 1) { $_SESSION['cart'][$id]['qty']--; }
        else { unset($_SESSION['cart'][$id]); }
    } elseif ($action == 'remove') { unset($_SESSION['cart'][$id]); }
}
$from = $_GET['from'] ?? '';
header("Location: " . ($from == 'cart' ? 'keranjang.php' : 'user_dashboard.php'));
exit;