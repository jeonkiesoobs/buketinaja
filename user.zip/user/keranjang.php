<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['login'])) header("Location: ../login.php");
$grand_total = 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Saya</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8fafc; padding: 50px; }
        .cart-item { background: white; padding: 20px; border-radius: 20px; display: flex; align-items: center; margin-bottom: 15px; border: 1px solid #e2e8f0; }
        .btn-checkout { background: #2563eb; color: white; padding: 15px 40px; border-radius: 15px; text-decoration: none; font-weight: 800; display: inline-block; margin-top: 20px; }
    </style>
</head>
<body>
    <div style="max-width: 800px; margin: 0 auto;">
        <h2>Keranjang Belanja 🛒</h2>
        <?php if (empty($_SESSION['cart'])): ?>
            <p>Kosong. <a href="user_dashboard.php">Belanja Sekarang</a></p>
        <?php else: ?>
            <?php foreach ($_SESSION['cart'] as $id => $item): 
                $grand_total += ($item['harga'] * $item['qty']); ?>
                <div class="cart-item">
                    <img src="../assets/<?= $item['gambar'] ?>" width="70" height="70" style="border-radius: 10px; object-fit: cover; margin-right: 20px;">
                    <div style="flex:1;">
                        <b><?= $item['nama'] ?></b><br>
                        Rp <?= number_format($item['harga'], 0, ',', '.') ?> x <?= $item['qty'] ?>
                    </div>
                    <a href="update_cart.php?id=<?= $id ?>&action=remove&from=cart" style="color: red; text-decoration: none;">Hapus</a>
                </div>
            <?php endforeach; ?>
            <h3>Total: Rp <?= number_format($grand_total, 0, ',', '.') ?></h3>
            <a href="checkout.php?source=cart" class="btn-checkout">Lanjut Checkout</a>
        <?php endif; ?>
    </div>
</body>
</html>