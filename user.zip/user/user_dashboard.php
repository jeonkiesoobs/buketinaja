<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['login'])) { header("Location: ../login.php"); exit; }

$user_id = $_SESSION['id'];
$user_nama = $_SESSION['nama'] ?? 'Pelanggan';

// Ambil data produk dari tabel produk_buket
$res = mysqli_query($conn, "SELECT * FROM produk_buket ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Katalog | Buketin Aja</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --p: #2563eb; --soft: #eff6ff; --dark: #0f172a; --bg: #f8fafc; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); margin: 0; padding-top: 80px; }
        .navbar { position: fixed; top: 0; width: 100%; background: white; padding: 15px 8%; display: flex; justify-content: space-between; align-items: center; z-index: 1000; border-bottom: 1px solid #e2e8f0; box-sizing: border-box; }
        .logo { font-weight: 800; font-size: 1.5rem; text-decoration: none; color: var(--dark); }
        .logo span { color: var(--p); }
        
        .container { max-width: 1200px; margin: 0 auto; padding: 20px 5%; }
        
        /* Promo Banner */
        .hero-banner { background: linear-gradient(135deg, var(--dark) 0%, #1e293b 100%); color: white; border-radius: 30px; padding: 40px; margin-bottom: 40px; position: relative; overflow: hidden; }
        .hero-banner h1 { font-size: 2.2rem; margin: 0; }
        .hero-banner p { opacity: 0.8; margin: 10px 0 20px; }
        .promo-tag { background: #f59e0b; color: var(--dark); padding: 5px 15px; border-radius: 50px; font-weight: 800; font-size: 0.8rem; display: inline-block; }

        /* Product Grid */
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 25px; }
        .card { background: white; border-radius: 25px; padding: 15px; border: 1px solid #e2e8f0; transition: 0.3s; position: relative; }
        .card:hover { transform: translateY(-10px); box-shadow: 0 20px 40px rgba(0,0,0,0.05); }
        .img-box { width: 100%; height: 280px; border-radius: 20px; overflow: hidden; background: #f1f5f9; margin-bottom: 15px; }
        .img-box img { width: 100%; height: 100%; object-fit: cover; }
        
        .price { color: var(--p); font-weight: 800; font-size: 1.3rem; display: block; margin-bottom: 15px; }
        .btn-order { display: block; width: 100%; padding: 14px; background: var(--dark); color: white; text-align: center; text-decoration: none; border-radius: 15px; font-weight: 700; transition: 0.3s; }
        .btn-order:hover { background: var(--p); }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="user_dashboard.php" class="logo">Buket<span>.aja</span></a>
        <div style="display: flex; gap: 20px; align-items: center;">
            <a href="pesanan_saya.php" style="text-decoration:none; color:#64748b; font-weight:700;">Pesanan Saya</a>
            <a href="profil.php" style="color:var(--dark); font-size:1.3rem;"><i class="fas fa-user-circle"></i></a>
            <a href="../logout.php" style="color:#ef4444;"><i class="fas fa-power-off"></i></a>
        </div>
    </nav>

    <div class="container">
        <div class="hero-banner">
            <h1>Halo, <?= htmlspecialchars(explode(' ', $user_nama)[0]) ?>! ✨</h1>
            <p>Temukan buket bunga terbaik untuk momen spesialmu.</p>
            <div class="promo-tag">DISKON 20% MINGGU INI</div>
            <i class="fas fa-leaf fa-8x" style="position:absolute; right:-20px; bottom:-20px; opacity:0.1;"></i>
        </div>

        <h2 style="margin-bottom: 25px; font-weight: 800;">Katalog Produk</h2>
        <div class="grid">
            <?php while($p = mysqli_fetch_assoc($res)): ?>
                <div class="card">
                    <div class="img-box"><img src="../assets/<?= $p['gambar'] ?>" onerror="this.src='https://via.placeholder.com/400'"></div>
                    <h3 style="font-size: 1.1rem; margin-bottom: 5px;"><?= htmlspecialchars($p['nama_buket']) ?></h3>
                    <span class="price">Rp <?= number_format($p['harga'], 0, ',', '.') ?></span>
                    <a href="checkout.php?id=<?= $p['id'] ?>" class="btn-order">Pesan Sekarang</a>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>