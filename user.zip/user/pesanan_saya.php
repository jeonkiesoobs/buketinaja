<?php
session_start();
@include '../koneksi.php';

// Proteksi Halaman
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit;
}

// Inisialisasi Keranjang jika belum ada
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Menghitung Total Harga di Keranjang
$grand_total = 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja | Buketin Aja</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #2563eb;
            --bg: #f8fafc;
            --white: #ffffff;
            --text: #0f172a;
            --border: #e2e8f0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: var(--bg); color: var(--text); padding-top: 90px; }

        .navbar {
            position: fixed; top: 0; width: 100%; background: rgba(255,255,255,0.85);
            backdrop-filter: blur(15px); padding: 15px 8%;
            display: flex; justify-content: space-between; align-items: center;
            z-index: 1000; border-bottom: 1px solid var(--border);
        }
        .logo { font-weight: 800; font-size: 1.4rem; text-decoration: none; color: var(--text); }
        .logo span { color: var(--primary); }

        .container { max-width: 1000px; margin: 0 auto; padding: 20px 5%; }

        .cart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .btn-back { text-decoration: none; color: var(--primary); font-weight: 700; font-size: 0.9rem; }

        /* ITEM CARD */
        .cart-item {
            background: var(--white); border-radius: 20px; padding: 20px;
            margin-bottom: 15px; border: 1px solid var(--border);
            display: flex; align-items: center; gap: 20px;
        }
        .item-img { width: 100px; height: 100px; border-radius: 15px; object-fit: cover; background: #f1f5f9; }
        .item-info { flex: 1; }
        .item-info h4 { font-weight: 700; font-size: 1.1rem; margin-bottom: 5px; }
        .item-price { color: var(--primary); font-weight: 800; }

        .item-qty { display: flex; align-items: center; gap: 15px; }
        .qty-btn { 
            width: 32px; height: 32px; border-radius: 10px; border: 1px solid var(--border);
            background: white; cursor: pointer; display: flex; align-items: center; justify-content: center;
            text-decoration: none; color: var(--text); font-weight: bold;
        }

        .btn-remove { color: #ef4444; text-decoration: none; font-size: 1.2rem; margin-left: 20px; }

        /* SUMMARY */
        .cart-summary {
            background: var(--white); border-radius: 25px; padding: 30px;
            margin-top: 30px; border: 1px solid var(--border);
        }
        .summary-row { display: flex; justify-content: space-between; margin-bottom: 15px; font-weight: 600; }
        .total-price { font-size: 1.5rem; font-weight: 800; color: var(--primary); }

        .btn-checkout {
            display: block; width: 100%; padding: 18px; background: var(--text);
            color: white; text-align: center; text-decoration: none; border-radius: 15px;
            font-weight: 800; margin-top: 20px; transition: 0.3s;
        }
        .btn-checkout:hover { background: var(--primary); transform: translateY(-3px); }

        .empty-cart { text-align: center; padding: 80px 0; opacity: 0.5; }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="user_dashboard.php" class="logo">Buket<span>.aja</span></a>
        <a href="user_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Belanja Lagi</a>
    </nav>

    <div class="container">
        <div class="cart-header">
            <h2 style="font-weight: 800; font-size: 1.8rem; letter-spacing: -1px;">Keranjang Saya</h2>
            <span style="font-weight: 700; color: #64748b;"><?php echo count($_SESSION['cart']); ?> Items</span>
        </div>

        <?php if (empty($_SESSION['cart'])): ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-basket fa-4x"></i>
                <h3 style="margin-top:20px;">Keranjangmu masih kosong</h3>
                <p>Ayo cari buket cantik untuk orang spesial!</p>
            </div>
        <?php else: ?>
            <?php 
            foreach ($_SESSION['cart'] as $id => $item): 
                $subtotal = $item['harga'] * $item['qty'];
                $grand_total += $subtotal;
            ?>
                <div class="cart-item">
                    <img src="../assets/<?php echo $item['gambar']; ?>" class="item-img" onerror="this.src='https://via.placeholder.com/150'">
                    <div class="item-info">
                        <h4><?php echo htmlspecialchars($item['nama']); ?></h4>
                        <p class="item-price">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></p>
                    </div>
                    <div class="item-qty">
                        <a href="update_cart.php?id=<?php echo $id; ?>&action=minus" class="qty-btn">-</a>
                        <span style="font-weight: 800;"><?php echo $item['qty']; ?></span>
                        <a href="update_cart.php?id=<?php echo $id; ?>&action=plus" class="qty-btn">+</a>
                    </div>
                    <a href="update_cart.php?id=<?php echo $id; ?>&action=remove" class="btn-remove" onclick="return confirm('Hapus item ini?')">
                        <i class="fas fa-trash-alt"></i>
                    </a>
                </div>
            <?php endforeach; ?>

            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal Produk</span>
                    <span>Rp <?php echo number_format($grand_total, 0, ',', '.'); ?></span>
                </div>
                <div class="summary-row">
                    <span>Biaya Layanan</span>
                    <span>Gratis</span>
                </div>
                <hr style="margin-bottom: 20px; border: none; border-top: 1px dashed var(--border);">
                <div class="summary-row">
                    <span style="font-size: 1.2rem; font-weight: 800;">Total Bayar</span>
                    <span class="total-price">Rp <?php echo number_format($grand_total, 0, ',', '.'); ?></span>
                </div>
                
                <a href="order_form.php?source=cart" class="btn-checkout">Lanjut Checkout</a>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>